# spring-rce-poc

Quick test setup to replicate the spring-rce (<insert CVE here>):\
Deploy a docker container with Tomcat, SpringMVC and a vulnerable app.\
Then run the exploit.

## Requirements

Docker

## How-To

First run deploy.sh to build and deploy the docker container\
Wait untill the docker is up & running\
then run exploit.sh
