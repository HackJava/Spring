#!/bin/bash
#

docker image build -t retro/stupidrumor ./ && docker container run -it --publish 8080:8080 retro/stupidrumor
